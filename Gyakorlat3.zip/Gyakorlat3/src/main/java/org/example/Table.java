package org.example;

public class Table {
    private int width;
    private int length;
    private int height;
    private boolean isAdjustable;
    private int currentHeight;

    public Table(int width, int length, int height) {
        this(width, length, height, false, height);
    }

    public Table(int width, int length, int height, boolean isAdjustable, int currentHeight) {
        this.width = width;
        this.length = length;
        this.height = height;
        this.isAdjustable = isAdjustable;
        this.currentHeight = currentHeight;
    }

    public void setHeight(int newHeight) {
        if (isAdjustable && newHeight >= 0 && newHeight <= 200) {
            this.currentHeight = newHeight;
        }
    }

    public int area() {
        return width * length;
    }

    public int getCapacity() {
        return (2 * (width + length)) / 60;
    }

    public int getWidth() { return width; }
    public int getLength() { return length; }
    public int getHeight() { return height; }
    public boolean isAdjustable() { return isAdjustable; }
    public int getCurrentHeight() { return currentHeight; }
}