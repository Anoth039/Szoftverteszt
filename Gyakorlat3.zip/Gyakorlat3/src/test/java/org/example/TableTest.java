package org.example;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;
import static org.junit.jupiter.api.Assertions.*;

class TableTest {

    @Test
    @DisplayName("area() = width * length, normál esetben")
    void area_normalCase() {
        Table table = new Table(100, 50, 75);
        assertEquals(5000, table.area());
    }

    @Test
    @DisplayName("area() = 0, ha a szélesség 0")
    void area_zeroWidth() {
        Table table = new Table(0, 50, 75);
        assertEquals(0, table.area());
    }

    @Test
    @DisplayName("area() négyzet alakú asztalnál")
    void area_squareTable() {
        Table table = new Table(80, 80, 75);
        assertEquals(6400, table.area());
    }

    @Test
    @DisplayName("getCapacity(): kerület / 60")
    void getCapacity_normalCase() {
        Table table = new Table(120, 60, 75);
        assertEquals(6, table.getCapacity());
    }

    @Test
    @DisplayName("getCapacity(): nem kerek osztás esetén lefelé kerekít")
    void getCapacity_roundsDown() {
        Table table = new Table(100, 40, 75);
        assertEquals(4, table.getCapacity());
    }

    @Test
    @DisplayName("getCapacity(): nagyon kis asztalnál akár 0 is lehet")
    void getCapacity_verySmallTable() {
        Table table = new Table(10, 10, 75);
        assertEquals(0, table.getCapacity());
    }

    @Test
    @DisplayName("setHeight(): beállítja az új magasságot, ha állítható és érvényes tartományban van")
    void setHeight_validValue_whenAdjustable() {
        Table table = new Table(100, 50, 75, true, 75);
        table.setHeight(90);
        assertEquals(90, table.getCurrentHeight());
    }

    @Test
    @DisplayName("setHeight(): alsó határérték (0) elfogadott, ha állítható")
    void setHeight_lowerBoundary() {
        Table table = new Table(100, 50, 75, true, 75);
        table.setHeight(0);
        assertEquals(0, table.getCurrentHeight());
    }

    @Test
    @DisplayName("setHeight(): felső határérték (200) elfogadott, ha állítható")
    void setHeight_upperBoundary() {
        Table table = new Table(100, 50, 75, true, 75);
        table.setHeight(200);
        assertEquals(200, table.getCurrentHeight());
    }

    @Test
    @DisplayName("setHeight(): nem változtat, ha az asztal nem állítható")
    void setHeight_notAdjustable_doesNothing() {
        Table table = new Table(100, 50, 75);
        table.setHeight(120);
        assertEquals(75, table.getCurrentHeight());
    }

    @Test
    @DisplayName("setHeight(): nem változtat, ha az új érték negatív (még ha állítható is)")
    void setHeight_belowRange_doesNothing() {
        Table table = new Table(100, 50, 75, true, 75);
        table.setHeight(-10);
        assertEquals(75, table.getCurrentHeight());
    }

    @Test
    @DisplayName("setHeight(): nem változtat, ha az új érték 200 fölötti (még ha állítható is)")
    void setHeight_aboveRange_doesNothing() {
        Table table = new Table(100, 50, 75, true, 75);
        table.setHeight(250);
        assertEquals(75, table.getCurrentHeight());
    }

}