package org.example;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;

class BankAccountTest {

    private static final double DELTA = 0.0001;

    private BankAccount account;

    @BeforeEach
    void setUp() {
        account = new BankAccount();
    }

    @Test
    void newAccountHasZeroBalance() {
        assertEquals(0, account.getBalance(), DELTA);
    }

    @Test
    void depositIncreasesBalance() {
        account.deposit(1000);
        assertEquals(1000, account.getBalance(), DELTA);
    }

    @Test
    void multipleDepositsAreSummed() {
        account.deposit(1000);
        account.deposit(500);
        account.deposit(250.5);
        assertEquals(1750.5, account.getBalance(), DELTA);
    }

    @Test
    void withdrawDecreasesBalance() {
        account.deposit(1000);
        account.withdraw(400);
        assertEquals(600, account.getBalance(), DELTA);
    }

    @Test
    void fullBalanceCanBeWithdrawn() {
        account.deposit(1000);
        account.withdraw(1000);
        assertEquals(0, account.getBalance(), DELTA);
    }

    @Test
    void withdrawMoreThanBalanceThrows() {
        account.deposit(1000);
        assertThrows(IllegalArgumentException.class, () -> account.withdraw(1000.01));
        assertEquals(1000, account.getBalance(), DELTA); // az egyenleg nem változott
    }

    @Test
    void negativeDepositThrows() {
        assertThrows(IllegalArgumentException.class, () -> account.deposit(-100));
    }

    @Test
    void zeroDepositThrows() {
        assertThrows(IllegalArgumentException.class, () -> account.deposit(0));
    }

    @Test
    void negativeWithdrawThrows() {
        account.deposit(1000);
        assertThrows(IllegalArgumentException.class, () -> account.withdraw(-100));
    }

    @Test
    void zeroWithdrawThrows() {
        account.deposit(1000);
        assertThrows(IllegalArgumentException.class, () -> account.withdraw(0));
    }
}