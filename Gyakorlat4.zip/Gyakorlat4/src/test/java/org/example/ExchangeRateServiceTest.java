package org.example;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

public class ExchangeRateServiceTest {

    ExchangeRateService rateService = mock(ExchangeRateService.class);

    @Test
    void returnsMockedRate() {
        when(rateService.getRate("EUR", "HUF")).thenReturn(400.0);

        assertEquals(400.0, rateService.getRate("EUR", "HUF"), 0.0001);
    }
}