package org.example;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

class UserTest {

    @Test
    void mockedUserReturnsStubbedData() {
        User user = mock(User.class);

        when(user.getUserName()).thenReturn("TesztElek");
        when(user.getPassword()).thenReturn("TOPSECRET");
        when(user.isLoggedIn()).thenReturn(true);
        when(user.getId()).thenReturn(123);

        assertEquals("TesztElek", user.getUserName());
        assertEquals("TOPSECRET", user.getPassword());
        assertTrue(user.isLoggedIn());
        assertEquals(123, user.getId());

        // az egyes metódusok meghívásának ellenőrzése
        verify(user).getUserName();
        verify(user).getPassword();
        verify(user).isLoggedIn();
        verify(user).getId();
    }

    @Test
    void verifyCountsInvocations() {
        User user = mock(User.class);

        user.login();
        user.login();
        user.logout();

        verify(user, times(2)).login();
        verify(user, times(1)).logout();
    }

    @Test
    void updatePwdCallsDatabase() {
        UserDatabase database = mock(UserDatabase.class);
        User user = new User(123, "TesztElek", "TOPSECRET", database);

        user.updatePwd("UjJelszo", true);

        verify(database).setPassword(123, "UjJelszo");
        assertEquals("UjJelszo", user.getPassword());
    }

    @Test
    void realDatabaseThrowsUnsupportedOperationException() {
        User user = new User(123, "TesztElek", "TOPSECRET", new UserDatabase());

        assertThrows(UnsupportedOperationException.class,
                () -> user.updatePwd("UjJelszo", true));
    }
}